#include "cmd_parser.hpp"
const std::string CmdParser::Parser::regex_long_suffix = "=(\\S+)";
const std::string CmdParser::Parser::regex_short_suffix = "\\s+(\\S+)";
